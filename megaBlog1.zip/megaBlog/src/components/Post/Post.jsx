
import React, { useCallback, useEffect } from 'react'
import { useSelector } from 'react-redux'
import { useForm } from 'react-hook-form'
import service from '../../appwrite/config.js'
import { RTE, Button, Input, Select } from '../index'
import { useNavigate } from 'react-router-dom'

function Post({ post }) {

    const {
        register,
        handleSubmit,
        control,
        setValue,
        watch
    } = useForm({
        defaultValues: {
            title: post?.title || '',
            slug: post?.slug || '',
            content: post?.content || '',
            status: post?.status || 'active',
        }
    })

    const navigate = useNavigate()

    const userData = useSelector((state) => state.auth.userData)

    // Convert title into slug
    const slugTransform = useCallback((value) => {
        if (value && typeof value === 'string') {
            return value
                .trim()
                .toLowerCase()
                .replace(/\s+/g, '-')
        }

        return ''
    }, [])

    // Watch title changes
    useEffect(() => {
        const subscription = watch((value, { name }) => {
            if (name === 'title') {
                setValue('slug', slugTransform(value.title), {
                    shouldValidate: true
                })
            }
        })

        return () => subscription.unsubscribe()

    }, [watch, slugTransform, setValue])

    // Submit function
    const submit = async (data) => {
        try {

            // Check logged-in user when creating a post
            if (!post && !userData?.$id) {
                console.log('User is not logged in')
                return
            }

            // Get selected image
            const selectedFile = data.image?.[0]

            // Upload image if selected
            const file = selectedFile
                ? await service.uploadFile(selectedFile)
                : null

            // Image is required when creating a post
            if (!post && !file?.$id) {
                console.log('Please select a featured image')
                return
            }

            // Get image ID
            const featuredImage = file?.$id || post?.featuredImage

            // Remove image from form data
            const { image, ...postData } = data

            if (post) {

                // Update existing post
                if (!featuredImage) {
                    console.log('Featured image is missing')
                    return
                }

                const dbPost = await service.updatePost(post.$id, {
                    ...postData,
                    featuredImage
                })

                if (dbPost) {

                    // Delete old image only after successful update
                    if (file && post.featuredImage) {
                        await service.deleteFile(post.featuredImage)
                    }

                    navigate(`/post/${post.$id}`)
                }

            } else {

                // Create new post
                const dbPost = await service.createPost({
                    ...postData,
                    featuredImage,
                    userId: userData.$id
                })

                if (dbPost) {
                    navigate(`/post/${dbPost.$id}`)
                }
            }

        } catch (error) {
            console.log('Post::submit::error', error)
        }
    }

    return (
        <div className="w-full bg-white border border-gray-200 rounded-xl p-6 sm:p-8 shadow-sm">

            <form onSubmit={handleSubmit(submit)} className="space-y-6">

                {/* Title */}
                <div>
                    <Input
                        label="Title"
                        type="text"
                        placeholder="Enter title"
                        {...register('title', {
                            required: true,
                            pattern: {
                                value: /^(?![ -.&,_'":?!])(?!.*[- &'":$])(?!.*[-.#@&,:?!]{2})[a-zA-Z0-9 .#@&,_'":.?!]+$/,
                                message: "Enter a valid title"
                            }
                        })}
                    />
                </div>

                {/* Slug */}
                <div>
                    <Input
                        label="Slug"
                        {...register('slug', {
                            required: true
                        })}
                    />
                </div>

                {/* Rich Text Editor */}
                <div>
                    <RTE
                        label="Content"
                        name="content"
                        control={control}
                        defaultValue={post?.content || ''}
                    />
                </div>

                {/* Featured Image */}
                <div>
                    <Input
                        label="Featured Image"
                        type="file"
                        accept="image/*"
                        {...register('image', {
                            required: !post
                        })}
                    />
                </div>

                {/* Existing Image Preview */}
                {post?.featuredImage?.trim() && (
                    <div className="mt-4 overflow-hidden rounded-lg border border-gray-200">
                        <img
                            src={service.filePreview(post.featuredImage)}
                            alt={post.title || 'Featured image'}
                            className="w-full max-h-64 object-cover"
                        />
                    </div>
                )}

                {/* Status */}
                <div>
                    <Select
                        label="Status"
                        options={["active", "inactive"]}
                        {...register('status', {
                            required: true
                        })}
                    />
                </div>

                {/* Submit Button */}
                <div className="pt-2">
                    <Button type="submit">
                        {post ? 'Update Post' : 'Create Post'}
                    </Button>
                </div>

            </form>
        </div>
    )
}

export default Post
